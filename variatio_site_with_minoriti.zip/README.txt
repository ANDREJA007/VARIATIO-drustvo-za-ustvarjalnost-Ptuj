VARIATIO – Ready-to-upload site
--------------------------------
1) In your GitHub repo, click: Add file → Upload files
2) Upload the entire folder contents:
   - index.html
   - /images (all files inside)
   - /assets/variatio_logo.png
3) Commit changes. Your site updates in ~10–60 seconds.
URL example: https://andreja007.github.io/VARIATIO-drustvo-za-ustvarjalnost-Ptuj/