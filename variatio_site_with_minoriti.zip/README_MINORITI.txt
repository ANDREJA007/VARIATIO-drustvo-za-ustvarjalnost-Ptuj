Minoriti gallery placeholders
-----------------------------
- Ko boš imela fotografije za OPERA V MINORITIH – Maribor, jih poimenuj npr.:
  minoriti_1.jpg, minoriti_2.jpg, minoriti_3.jpg ...
- Naloži jih v mapo `images/` poleg ostalih fotografij in stran jih bo sama prikazala.