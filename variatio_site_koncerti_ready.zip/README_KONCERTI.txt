Koncerti — kako dodaš nove fotografije
--------------------------------------
- Dodaj slike v mapo `images/` in poimenuj po dogodku, npr. `minoriti_1.jpg`, `masterclass_1.jpg`, `loka_1.jpg`...
- Ni treba nič spreminjati v HTML — če uporabiš enaka imena datotek, se bodo samodejno prikazale.